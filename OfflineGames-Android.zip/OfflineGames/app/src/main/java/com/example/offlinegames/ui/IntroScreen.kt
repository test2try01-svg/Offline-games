package com.example.offlinegames.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.offlinegames.data.Store
import kotlin.math.roundToInt

@Composable
fun IntroScreen(game: GameInfo, onBack: () -> Unit, onSettings: () -> Unit, onPlay: (Int) -> Unit) {
    StatusBarIcons(darkIcons = false)
    var idx by remember { mutableIntStateOf(Store.lastDifficulty(game.id)) }
    var showHelp by remember { mutableStateOf(false) }
    val d = Difficulty.entries[idx]
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val headerH = statusTop + 216.dp

    Box(Modifier.fillMaxSize().background(Pal.Cream)) {
        Hills()
        // header
        Box(Modifier.fillMaxWidth().height(headerH).background(game.headerBg)) {
            Column(Modifier.statusBarsPadding().padding(horizontal = 8.dp, vertical = 8.dp)) {
                Box(Modifier.fillMaxWidth().height(40.dp)) {
                    RoundButton(onBack, Modifier.align(Alignment.CenterStart)) { IconChevron() }
                    GText(game.title, 30, Color.White, Modifier.align(Alignment.Center))
                    RoundButton(onSettings, Modifier.align(Alignment.CenterEnd)) { IconGear() }
                }
                Spacer(Modifier.height(8.dp))
                GText(game.description, 15, Color.White, Modifier.fillMaxWidth().padding(horizontal = 12.dp))
            }
        }
        Column(Modifier.fillMaxSize().padding(top = headerH).navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(58.dp))
            GText(d.label, 44, d.color)
            Spacer(Modifier.height(24.dp))
            DifficultySlider(idx, d.color) { idx = it; Store.setLastDifficulty(game.id, it) }
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                BigButton(d.color, { onPlay(idx) }, Modifier.width(150.dp)) {
                    GText("PLAY", 38, Color.White)
                    if (game.hasLevels) GText("Level ${Store.level(game.id, idx)}", 17, Color.White)
                }
                BigButton(Pal.Purple, { showHelp = true }, Modifier.size(44.dp), radius = 10.dp) {
                    GText("?", 28, Color.White)
                }
            }
            Spacer(Modifier.height(96.dp))
        }
        // difficulty face straddling the header edge
        DifficultyFace(d, Modifier.padding(top = headerH - 47.dp).align(Alignment.TopCenter).size(94.dp))

        if (showHelp) Scrim {
            Column(
                Modifier.align(Alignment.Center).fillMaxWidth(0.86f).clip(RoundedCornerShape(32.dp))
                    .background(Pal.Cream).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GText("HOW TO PLAY", 26, Pal.Purple)
                Spacer(Modifier.height(12.dp))
                GText(game.description, 17, Pal.Slate, weight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                BigButton(Pal.Purple, { showHelp = false }, Modifier.width(140.dp)) { GText("OK", 22, Color.White) }
            }
        }
    }
}

@Composable
private fun DifficultySlider(index: Int, color: Color, onChange: (Int) -> Unit) {
    val cb by rememberUpdatedState(onChange)
    val frac by animateFloatAsState(index / 4f, label = "thumb")
    val pad = with(androidx.compose.ui.platform.LocalDensity.current) { 28.dp.toPx() }
    fun idxFor(x: Float, w: Float): Int = (((x - pad) / (w - 2 * pad)).coerceIn(0f, 1f) * 4).roundToInt()
    Canvas(
        Modifier
            .fillMaxWidth(0.82f)
            .height(64.dp)
            .pointerInput(Unit) { detectTapGestures { cb(idxFor(it.x, size.width.toFloat())) } }
            .pointerInput(Unit) { detectHorizontalDragGestures { ch, _ -> ch.consume(); cb(idxFor(ch.position.x, size.width.toFloat())) } }
    ) {
        val w = size.width
        val cy = size.height / 2
        val thumbX = pad + (w - 2 * pad) * frac
        val outerH = 44.dp.toPx()
        val innerH = 30.dp.toPx()
        drawRoundRect(Color.White, Offset(0f, cy - outerH / 2), Size(w, outerH), CornerRadius(outerH / 2))
        val tx = 10.dp.toPx()
        val trackW = w - 2 * tx
        // unfilled part: grey -> indigo -> magenta
        drawRoundRect(
            Brush.horizontalGradient(
                0f to Color(0xFF6B6B6B), 0.45f to Color(0xFF6B6B6B), 0.7f to Pal.Indigo, 0.93f to Pal.Magenta, 1f to Pal.Magenta,
                startX = tx, endX = tx + trackW
            ),
            Offset(tx, cy - innerH / 2), Size(trackW, innerH), CornerRadius(innerH / 2)
        )
        // filled part
        drawRoundRect(color, Offset(tx, cy - innerH / 2), Size((thumbX - tx).coerceAtLeast(innerH), innerH), CornerRadius(innerH / 2))
        drawCircle(Color.White, 28.dp.toPx(), Offset(thumbX, cy))
        drawCircle(color.darken(0.2f), 15.dp.toPx(), Offset(thumbX, cy))
    }
}
