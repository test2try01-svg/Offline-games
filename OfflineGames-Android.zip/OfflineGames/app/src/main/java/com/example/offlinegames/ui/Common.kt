package com.example.offlinegames.ui

import android.app.Activity
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.offlinegames.data.Bests
import com.example.offlinegames.data.Store
import kotlin.math.cos
import kotlin.math.sin

// ---------- system bars ----------
@Composable
fun StatusBarIcons(darkIcons: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = darkIcons
            c.isAppearanceLightNavigationBars = darkIcons
        }
    }
}

// ---------- icons (drawn, so no icon library is needed) ----------
@Composable
fun IconChevron(modifier: Modifier = Modifier.size(24.dp), color: Color = Pal.Pink) {
    Canvas(modifier) {
        val s = size.width
        val p = Path().apply {
            moveTo(s * 0.66f, s * 0.14f); lineTo(s * 0.3f, s * 0.5f); lineTo(s * 0.66f, s * 0.86f)
        }
        drawPath(p, color, style = Stroke(s * 0.17f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun IconClose(modifier: Modifier = Modifier.size(24.dp), color: Color = Pal.Pink) {
    Canvas(modifier) {
        val s = size.width
        drawLine(color, Offset(s * .2f, s * .2f), Offset(s * .8f, s * .8f), s * .16f, StrokeCap.Round)
        drawLine(color, Offset(s * .8f, s * .2f), Offset(s * .2f, s * .8f), s * .16f, StrokeCap.Round)
    }
}

@Composable
fun IconGear(modifier: Modifier = Modifier.size(26.dp), color: Color = Pal.Pink, hole: Color = Color.White) {
    Canvas(modifier) {
        val s = size.width
        val c = center
        for (i in 0 until 8) {
            rotate(i * 45f, pivot = c) {
                drawRoundRect(color, Offset(c.x - s * .09f, s * .03f), Size(s * .18f, s * .27f), CornerRadius(s * .04f))
            }
        }
        drawCircle(color, s * .33f, c)
        drawCircle(hole, s * .14f, c)
    }
}

@Composable
fun IconUndo(modifier: Modifier = Modifier.size(30.dp), color: Color) {
    Canvas(modifier) {
        val s = size.width
        val st = Stroke(s * .12f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val body = Path().apply {
            moveTo(s * .22f, s * .38f); lineTo(s * .6f, s * .38f)
            cubicTo(s * .85f, s * .38f, s * .85f, s * .72f, s * .6f, s * .72f)
            lineTo(s * .35f, s * .72f)
        }
        drawPath(body, color, style = st)
        val head = Path().apply {
            moveTo(s * .38f, s * .2f); lineTo(s * .2f, s * .38f); lineTo(s * .38f, s * .56f)
        }
        drawPath(head, color, style = st)
    }
}

@Composable
fun IconRestart(modifier: Modifier = Modifier.size(28.dp), color: Color = Pal.Pink) {
    Canvas(modifier) {
        val s = size.width
        drawArc(
            color, startAngle = -40f, sweepAngle = 285f, useCenter = false,
            topLeft = Offset(s * .2f, s * .2f), size = Size(s * .6f, s * .6f),
            style = Stroke(s * .13f, cap = StrokeCap.Round)
        )
        val head = Path().apply {
            moveTo(s * .5f, s * .06f); lineTo(s * .5f, s * .34f); lineTo(s * .28f, s * .2f); close()
        }
        drawPath(head, color)
    }
}

@Composable
fun IconBulb(modifier: Modifier = Modifier.size(34.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val s = size.width
        drawCircle(color, s * .2f, Offset(s * .5f, s * .4f), style = Stroke(s * .08f))
        drawLine(color, Offset(s * .4f, s * .7f), Offset(s * .6f, s * .7f), s * .07f, StrokeCap.Round)
        drawLine(color, Offset(s * .43f, s * .8f), Offset(s * .57f, s * .8f), s * .07f, StrokeCap.Round)
        for (a in listOf(-90f, -45f, -135f, 0f, 180f)) {
            val r = Math.toRadians(a.toDouble())
            val c = Offset(s * .5f, s * .4f)
            drawLine(
                color,
                Offset(c.x + (s * .32f * cos(r)).toFloat(), c.y + (s * .32f * sin(r)).toFloat()),
                Offset(c.x + (s * .42f * cos(r)).toFloat(), c.y + (s * .42f * sin(r)).toFloat()),
                s * .06f, StrokeCap.Round
            )
        }
    }
}

@Composable
fun IconPlus(modifier: Modifier = Modifier.size(30.dp), color: Color = Color.White) {
    Canvas(modifier) {
        val s = size.width
        drawLine(color, Offset(s * .5f, s * .2f), Offset(s * .5f, s * .8f), s * .16f, StrokeCap.Round)
        drawLine(color, Offset(s * .2f, s * .5f), Offset(s * .8f, s * .5f), s * .16f, StrokeCap.Round)
    }
}

@Composable
fun IconHome(modifier: Modifier = Modifier.size(34.dp), color: Color = Color.White, hole: Color) {
    Canvas(modifier) {
        val s = size.width
        val roof = Path().apply { moveTo(s * .5f, s * .12f); lineTo(s * .94f, s * .5f); lineTo(s * .06f, s * .5f); close() }
        drawPath(roof, color)
        drawRect(color, Offset(s * .16f, s * .48f), Size(s * .68f, s * .4f))
        drawRoundRect(hole, Offset(s * .42f, s * .6f), Size(s * .16f, s * .28f), CornerRadius(s * .03f))
    }
}

@Composable
fun IconTrophy(color: Color, modifier: Modifier = Modifier.size(24.dp)) {
    Canvas(modifier) {
        val s = size.width
        val cup = Path().apply {
            moveTo(s * .22f, s * .1f); lineTo(s * .78f, s * .1f)
            lineTo(s * .7f, s * .5f); lineTo(s * .3f, s * .5f); close()
        }
        drawPath(cup, color)
        drawCircle(color, s * .16f, Offset(s * .14f, s * .28f), style = Stroke(s * .07f))
        drawCircle(color, s * .16f, Offset(s * .86f, s * .28f), style = Stroke(s * .07f))
        drawRect(color, Offset(s * .44f, s * .5f), Size(s * .12f, s * .25f))
        drawRoundRect(color, Offset(s * .28f, s * .75f), Size(s * .44f, s * .14f), CornerRadius(s * .04f))
    }
}

@Composable
fun Hamburger(modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 30.dp, height = 20.dp)) {
        val h = 4.dp.toPx()
        drawRoundRect(Pal.Pink, Offset(0f, 0f), Size(size.width, h), CornerRadius(h))
        drawRoundRect(Pal.Pink, Offset(0f, 11.dp.toPx()), Size(size.width * 0.65f, h), CornerRadius(h))
    }
}

// ---------- characters ----------
@Composable
fun CatFace(modifier: Modifier = Modifier.size(40.dp)) {
    Canvas(modifier) {
        val s = size.width
        val dark = Color(0xFF2A2A2E)
        val ear1 = Path().apply { moveTo(s * .1f, s * .45f); lineTo(s * .16f, s * .08f); lineTo(s * .45f, s * .22f); close() }
        val ear2 = Path().apply { moveTo(s * .9f, s * .45f); lineTo(s * .84f, s * .08f); lineTo(s * .55f, s * .22f); close() }
        drawPath(ear1, dark); drawPath(ear2, dark)
        drawOval(Color.White, Offset(s * .06f, s * .2f), Size(s * .88f, s * .72f))
        drawOval(dark, Offset(s * .12f, s * .2f), Size(s * .76f, s * .3f))
        drawPath(Path().apply { moveTo(s * .5f, s * .22f); lineTo(s * .42f, s * .55f); lineTo(s * .58f, s * .55f); close() }, Color.White)
        for (x in listOf(.33f, .67f)) {
            drawCircle(dark, s * .1f, Offset(s * x, s * .55f))
            drawCircle(Color.White, s * .035f, Offset(s * x + s * .02f, s * .52f))
        }
        drawCircle(Color(0xFFF0A0A8), s * .05f, Offset(s * .5f, s * .68f))
    }
}

/** Difficulty faces shown on the intro screen (simplified from the screenshots). */
@Composable
fun DifficultyFace(d: Difficulty, modifier: Modifier = Modifier.size(94.dp)) {
    Canvas(modifier) {
        val s = size.width
        val c = center
        val black = Color.Black
        when (d) {
            Difficulty.Hard -> {
                for (sx in listOf(-1f, 1f)) {
                    val horn = Path().apply {
                        moveTo(c.x + sx * s * .28f, c.y - s * .18f)
                        lineTo(c.x + sx * s * .44f, c.y - s * .44f)
                        lineTo(c.x + sx * s * .5f, c.y - s * .2f); close()
                    }
                    drawPath(horn, Color.White, style = Stroke(s * .08f, join = StrokeJoin.Round))
                    drawPath(horn, black)
                }
            }
            Difficulty.ExtraHard -> {
                for (sx in listOf(-1f, 1f)) {
                    drawCircle(Color.White, s * .2f, Offset(c.x + sx * s * .26f, c.y - s * .32f))
                    drawCircle(black, s * .16f, Offset(c.x + sx * s * .26f, c.y - s * .32f))
                }
            }
            Difficulty.UltraHard -> {
                val crown = Path().apply {
                    moveTo(c.x - s * .2f, c.y - s * .3f); lineTo(c.x - s * .16f, c.y - s * .52f)
                    lineTo(c.x - s * .06f, c.y - s * .4f); lineTo(c.x, c.y - s * .55f)
                    lineTo(c.x + s * .06f, c.y - s * .4f); lineTo(c.x + s * .16f, c.y - s * .52f)
                    lineTo(c.x + s * .2f, c.y - s * .3f); close()
                }
                drawPath(crown, Color.White, style = Stroke(s * .07f, join = StrokeJoin.Round))
                drawPath(crown, black)
            }
            else -> {}
        }
        drawCircle(Color.White, s * .5f, c)
        drawCircle(black, s * .4f, c)
        drawCircle(d.color, s * .3f, c)
        // eyes
        for (sx in listOf(-1f, 1f)) {
            val e = Offset(c.x + sx * s * .12f, c.y - s * .05f)
            drawOval(black, Offset(e.x - s * .09f, e.y - s * .08f), Size(s * .18f, s * .16f))
            drawCircle(Color.White, s * .03f, Offset(e.x - sx * s * .01f + s * .01f, e.y - s * .03f))
        }
        // mouth
        val mouthY = c.y + s * .17f
        when (d) {
            Difficulty.Easy -> drawArc(black, 20f, 140f, false, Offset(c.x - s * .1f, mouthY - s * .09f), Size(s * .2f, s * .14f), style = Stroke(s * .045f, cap = StrokeCap.Round))
            Difficulty.Medium, Difficulty.Hard -> drawRoundRect(black, Offset(c.x - s * .09f, mouthY - s * .02f), Size(s * .18f, s * .06f), CornerRadius(s * .03f))
            else -> drawArc(black, 200f, 140f, false, Offset(c.x - s * .1f, mouthY - s * .02f), Size(s * .2f, s * .14f), style = Stroke(s * .045f, cap = StrokeCap.Round))
        }
    }
}

// ---------- buttons ----------
@Composable
fun RoundButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 40.dp,
    bg: Color = Color.White,
    enabled: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(if (enabled) bg else bg.copy(alpha = 0.35f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content
    )
}

/** Chunky "pressable" button with a darker lower edge, like the original PLAY button. */
@Composable
fun BigButton(
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    radius: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier
            .clip(RoundedCornerShape(radius))
            .background(color.darken(0.12f))
            .clickable(onClick = onClick)
            .padding(bottom = 4.dp)
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(radius))
                .background(color)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, content = content)
        }
    }
}

@Composable
fun ActionButton(
    label: String,
    bg: Color,
    labelColor: Color,
    enabled: Boolean = true,
    badge: Int? = null,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            RoundButton(onClick, size = 60.dp, bg = bg, enabled = enabled) { icon() }
            if (badge != null) {
                Box(
                    Modifier.align(Alignment.TopEnd).size(24.dp).clip(CircleShape).background(Color.White),
                    contentAlignment = Alignment.Center
                ) { GText(badge.toString(), 13, Pal.Slate) }
            }
        }
        GText(label, 14, if (enabled) labelColor else labelColor.copy(alpha = 0.35f), Modifier.padding(top = 4.dp))
    }
}

// ---------- backgrounds ----------
@Composable
fun Hills(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawOval(Pal.CreamHill, Offset(-w * .2f, h - 150.dp.toPx()), Size(w * .7f, 130.dp.toPx()))
        drawOval(Pal.CreamHill, Offset(w * .35f, h - 160.dp.toPx()), Size(w * .9f, 140.dp.toPx()))
        drawRect(Pal.Ground, Offset(0f, h - 70.dp.toPx()), Size(w, 70.dp.toPx()))
    }
}

// ---------- overlays ----------
@Composable
fun Scrim(alpha: Float = 0.62f, content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = alpha))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        content = content
    )
}

@Composable
fun PillSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (checked) 28.dp else 0.dp, label = "switch")
    Box(
        Modifier
            .size(width = 66.dp, height = 36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(if (checked) Color(0xFFE6BEDA) else Color(0xFFD9D4CE))
            .clickable { onChange(!checked) }
    ) {
        if (checked) {
            Canvas(Modifier.padding(start = 8.dp).size(22.dp).align(Alignment.CenterStart)) {
                val s = size.width
                drawPath(
                    Path().apply { moveTo(s * .12f, s * .52f); lineTo(s * .4f, s * .78f); lineTo(s * .9f, s * .22f) },
                    Pal.Purple.lighten(0.2f), style = Stroke(s * .14f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
        Box(
            Modifier
                .padding(start = x)
                .size(38.dp)
                .align(Alignment.CenterStart)
                .clip(CircleShape)
                .background(if (checked) Pal.Purple else Color(0xFF9A948E))
        )
    }
}

@Composable
fun SettingsDialog(title: String, onClose: () -> Unit) {
    Scrim {
        Column(Modifier.fillMaxSize().statusBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).height(40.dp)) {
                GText(title, 28, Color.White, Modifier.align(Alignment.Center))
                RoundButton(onClose, Modifier.align(Alignment.CenterEnd)) { IconClose() }
            }
            Spacer(Modifier.height(56.dp))
            Column(
                Modifier
                    .fillMaxWidth(0.86f)
                    .clip(RoundedCornerShape(36.dp))
                    .background(Pal.Cream)
                    .padding(horizontal = 14.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GText("SETTINGS", 28, Pal.Slate)
                Spacer(Modifier.height(20.dp))
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Color.White).padding(18.dp)
                ) {
                    GText("GAME ASSISTANCE", 22, Pal.Purple, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        GText("Colorblind mode", 20, Pal.Slate, Modifier.weight(1f), align = androidx.compose.ui.text.style.TextAlign.Start)
                        PillSwitch(Store.colorblind) { Store.setColorblind(it) }
                    }
                }
            }
        }
    }
}

// ---------- in-game chrome ----------
@Composable
fun GameTopBar(
    textColor: Color,
    pill: String,
    title: String,
    pillBg: Color,
    onBack: () -> Unit,
    onRestart: (() -> Unit)?,
    restartEnabled: Boolean = true
) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).height(64.dp)) {
        RoundButton(onBack, Modifier.align(Alignment.CenterStart)) { IconChevron() }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            GText(
                pill, 12, Color.White,
                Modifier.clip(RoundedCornerShape(50)).background(pillBg).padding(horizontal = 24.dp, vertical = 2.dp)
            )
            GText(title, 28, textColor)
        }
        if (onRestart != null) {
            RoundButton(onRestart, Modifier.align(Alignment.CenterEnd), enabled = restartEnabled) { IconRestart() }
        }
    }
}

@Composable
fun GameOverCard(
    modeLabel: String,
    score: Int,
    bests: Bests,
    face: Difficulty,
    onHome: () -> Unit,
    onAgain: () -> Unit
) {
    Scrim(0.55f) {
        Column(Modifier.fillMaxSize().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(36.dp)).background(Color(0xFF7F5461)).padding(top = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GText("GAME OVER", 38, Color(0xFFFFE6D6))
                Spacer(Modifier.height(18.dp))
                GText("Score", 30, Color(0xFFFFAE78), weight = FontWeight.Bold)
                GText(score.toString(), 64, Color(0xFFFFAE78))
                Spacer(Modifier.height(10.dp))
                Box {
                    Column(
                        Modifier.padding(horizontal = 14.dp, vertical = 14.dp).fillMaxWidth()
                            .clip(RoundedCornerShape(30.dp)).background(Color(0xFFFFE6D9)).padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GText("$modeLabel MODE", 24, Color(0xFFF0B21E), Modifier.padding(top = 4.dp, bottom = 14.dp))
                        BestRow("Today's best", bests.today, Pal.Yellow)
                        BestRow("Week's best", bests.week, Color(0xFFFF7B9A))
                        BestRow("All-time best", bests.allTime, Pal.Teal)
                    }
                    DifficultyFace(face, Modifier.align(Alignment.TopCenter).size(70.dp))
                }
            }
            Spacer(Modifier.height(26.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                BigButton(Pal.RedDark, onHome, Modifier.size(width = 66.dp, height = 66.dp), radius = 14.dp) {
                    IconHome(Modifier.size(30.dp), Color.White, Pal.RedDark)
                }
                BigButton(Pal.Green, onAgain, Modifier.width(214.dp).height(66.dp), radius = 14.dp) {
                    GText("PLAY AGAIN", 24, Color.White)
                }
            }
        }
    }
}

@Composable
private fun BestRow(label: String, value: Int, color: Color) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(50)).background(Color(0xFF7F5461)).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconTrophy(color, Modifier.size(26.dp))
        GText(label, 20, color, Modifier.weight(1f), align = androidx.compose.ui.text.style.TextAlign.Start)
        GText(value.toString(), 20, color)
    }
}

@Composable
fun LevelCompleteCard(level: Int, onHome: () -> Unit, onNext: () -> Unit) {
    Scrim(0.55f) {
        Column(Modifier.fillMaxSize().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            GText("LEVEL $level", 28, Color(0xFFFFE6D6))
            GText("COMPLETE!", 44, Color.White)
            Spacer(Modifier.height(30.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                BigButton(Pal.RedDark, onHome, Modifier.size(66.dp), radius = 14.dp) {
                    IconHome(Modifier.size(30.dp), Color.White, Pal.RedDark)
                }
                BigButton(Pal.Green, onNext, Modifier.width(214.dp).height(66.dp), radius = 14.dp) {
                    GText("NEXT LEVEL", 22, Color.White)
                }
            }
        }
    }
}

