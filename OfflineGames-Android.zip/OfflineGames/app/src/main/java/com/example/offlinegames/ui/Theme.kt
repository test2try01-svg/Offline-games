package com.example.offlinegames.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

/**
 * Design tokens. ALL values are ESTIMATED from the supplied screenshots (the original
 * Unity assets/fonts were not recoverable from the archive), not read from source.
 */
object Pal {
    val Cream = Color(0xFFFCF0DF)
    val CreamHill = Color(0xFFFCE6D3)
    val Ground = Color(0xFFFCDCC4)
    val BarLine = Color(0xFFDDA68F)
    val Pink = Color(0xFFD08BB0)
    val Purple = Color(0xFF95599A)
    val Slate = Color(0xFF3C4654)
    val Green = Color(0xFF31B547)
    val Orange = Color(0xFFFDA80A)
    val Red = Color(0xFFFF5C58)
    val Indigo = Color(0xFF525DBF)
    val Magenta = Color(0xFFB3388C)
    val Yellow = Color(0xFFFDC22E)
    val RedDark = Color(0xFFD4706A)
    val Teal = Color(0xFF2FE0BC)
}

fun Color.darken(f: Float) = Color(red * (1 - f), green * (1 - f), blue * (1 - f), alpha)
fun Color.lighten(f: Float) = Color(red + (1 - red) * f, green + (1 - green) * f, blue + (1 - blue) * f, alpha)

/** The original uses a chunky rounded display face; a system heavy sans is the closest safe fallback. */
@Composable
fun GText(
    text: String,
    size: Int,
    color: Color,
    modifier: Modifier = Modifier,
    weight: FontWeight = FontWeight.Black,
    align: TextAlign = TextAlign.Center,
    maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = size.sp,
        lineHeight = (size * 1.18f).sp,
        fontWeight = weight,
        fontFamily = FontFamily.SansSerif,
        textAlign = align,
        maxLines = maxLines
    )
}

@Composable
fun OfflineGamesTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(primary = Pal.Purple, background = Pal.Cream, surface = Pal.Cream),
        content = content
    )
}
