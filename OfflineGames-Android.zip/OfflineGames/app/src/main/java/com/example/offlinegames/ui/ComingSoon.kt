package com.example.offlinegames.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Shown for games that are catalogued but not rebuilt yet (clearly labelled, not a fake game). */
@Composable
fun ComingSoonScreen(game: GameInfo, onBack: () -> Unit) {
    StatusBarIcons(darkIcons = false)
    Box(Modifier.fillMaxSize().background(game.screenBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Box(Modifier.fillMaxWidth().padding(8.dp)) {
                RoundButton(onBack) { IconChevron() }
            }
            Column(
                Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                GText(game.title, 30, Color(0xFF3C4654).let { if (game.screenBg.red + game.screenBg.green + game.screenBg.blue > 1.8f) it else Color.White })
                Spacer(Modifier.height(12.dp))
                GText("Not rebuilt yet. This game is scheduled for the next build stage.", 17, Color.Gray)
            }
        }
    }
}
