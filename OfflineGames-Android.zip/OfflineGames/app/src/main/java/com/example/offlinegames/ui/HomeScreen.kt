package com.example.offlinegames.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(onOpen: (GameInfo) -> Unit, onMenu: () -> Unit) {
    StatusBarIcons(darkIcons = true)
    Box(Modifier.fillMaxSize().background(Pal.Cream)) {
        Hills()
        Column(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxWidth().background(Color.White).statusBarsPadding()) {
                Box(
                    Modifier.fillMaxWidth().height(52.dp).clickable(onClick = onMenu).padding(start = 15.dp),
                    contentAlignment = Alignment.CenterStart
                ) { Hamburger() }
                Box(Modifier.fillMaxWidth().height(4.dp).background(Pal.BarLine))
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(start = 44.dp, end = 44.dp, top = 16.dp, bottom = 24.dp + 0.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(Games.all) { g -> GameCard(g) { onOpen(g) } }
                item { Spacer(Modifier.navigationBarsPadding()) }
            }
        }
    }
}

@Composable
private fun GameCard(g: GameInfo, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().aspectRatio(0.79f)) {
        Box(
            Modifier.fillMaxSize()
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White)
                .clickable(onClick = onClick)
                .padding(4.dp)
        ) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(g.cardBg)) {
                CardArt(g.id, Modifier.fillMaxSize())
                Column(Modifier.padding(start = 12.dp, top = 12.dp)) {
                    GText(g.title, 17, g.titleColor, align = androidx.compose.ui.text.style.TextAlign.Start)
                    Box(Modifier.padding(top = 4.dp).size(width = 46.dp, height = 4.dp).clip(RoundedCornerShape(2.dp)).background(g.titleColor))
                }
            }
        }
        if (g.badge != null) {
            val left = g.id == "nuts"
            GText(
                g.badge, if (left) 14 else 18, Color.White,
                Modifier
                    .align(if (left) Alignment.BottomStart else Alignment.CenterStart)
                    .offset(x = (-8).dp, y = if (left) (-48).dp else (-8).dp)
                    .rotate(-4f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(g.badgeColor)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

/** Simplified card illustrations (the original artwork lives inside Unity bundles and was not extracted). */
@Composable
private fun CardArt(id: String, modifier: Modifier) {
    val nutColors = listOf(Color(0xFF1FA21B), Color(0xFFFFC107), Color(0xFF1E6FE0), Color(0xFFE0243F))
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        when (id) {
            "nuts" -> for (i in 0 until 3) {
                val x = w * (0.2f + 0.3f * i)
                drawRoundRect(Color(0xFFC9CDD6), Offset(x - 6.dp.toPx(), h * 0.4f), Size(12.dp.toPx(), h * 0.4f), CornerRadius(4.dp.toPx()))
                for (k in 0..(1 + i)) drawRoundRect(
                    nutColors[(i + k) % 4], Offset(x - 22.dp.toPx(), h * 0.78f - (k + 1) * 14.dp.toPx()),
                    Size(44.dp.toPx(), 15.dp.toPx()), CornerRadius(6.dp.toPx())
                )
            }
            "petdoku" -> {
                val cols = listOf(Color(0xFF57B26A), Color(0xFFE0689A), Color(0xFFEA9C50), Color(0xFF4A8FDB))
                for (r in 0 until 3) for (c in 0 until 3) drawRoundRect(
                    cols[(r + c) % 4], Offset(w * (0.12f + c * 0.28f), h * (0.38f + r * 0.22f)),
                    Size(w * 0.25f, w * 0.25f), CornerRadius(8.dp.toPx())
                )
            }
            "snakes" -> for (i in 0 until 12) drawCircle(
                Color.hsv(i * 28f, 0.8f, 1f), 12.dp.toPx(),
                Offset(w * (0.15f + i * 0.065f), h * (0.82f - (i % 6) * 0.07f - i * 0.02f))
            )
            "pointers" -> for (i in 0 until 3) {
                val y = h * (0.45f + i * 0.17f)
                drawLine(Color(0xFF2F3E4B), Offset(w * .15f, y), Offset(w * .8f, y), 4.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFF2F3E4B), Offset(w * .8f, y), Offset(w * .72f, y - 8.dp.toPx()), 4.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFF2F3E4B), Offset(w * .8f, y), Offset(w * .72f, y + 8.dp.toPx()), 4.dp.toPx(), StrokeCap.Round)
            }
            "maze" -> for (r in 0 until 4) for (c in 0 until 4) if ((r + c) % 3 != 0) drawRect(
                if ((r * c) % 2 == 0) Color(0xFFE5326A) else Color(0xFF7886A8),
                Offset(w * (0.12f + c * 0.19f), h * (0.38f + r * 0.14f)), Size(w * 0.19f, h * 0.14f)
            )
            "matching" -> for (r in 0 until 3) for (c in 0 until 4) drawRect(
                if ((r + c) % 3 == 0) Color(0xFFB8E9F8) else Color.White,
                Offset(w * (0.04f + c * 0.23f), h * (0.4f + r * 0.2f)), Size(w * 0.23f, h * 0.2f)
            )
            "blocks" -> {
                val cols = listOf(Color(0xFFE03127), Color(0xFF7ED321), Color(0xFF00D9E0))
                for (i in 0 until 3) for (j in 0..i) drawRect(
                    cols[i], Offset(w * (0.12f + i * 0.28f), h * (0.45f + j * 0.15f)), Size(w * 0.24f, h * 0.14f)
                )
            }
            "guess" -> drawCircle(Color.White.copy(alpha = 0.25f), w * 0.3f, Offset(w * .5f, h * .62f), style = Stroke(10.dp.toPx()))
        }
    }
    if (id == "guess") Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { GText("?", 64, Color.White.copy(alpha = 0.6f), weight = FontWeight.Black) }
}
