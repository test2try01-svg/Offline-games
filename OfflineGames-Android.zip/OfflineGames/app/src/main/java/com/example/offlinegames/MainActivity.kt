package com.example.offlinegames

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import com.example.offlinegames.data.Store
import com.example.offlinegames.games.BlocksScreen
import com.example.offlinegames.games.NutsScreen
import com.example.offlinegames.games.PetdokuScreen
import com.example.offlinegames.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Store.init(this)
        setContent { OfflineGamesTheme { App() } }
    }
}

/** Route strings: "home" | "intro:<game>" | "play:<game>:<difficulty>" (saved across process recreation). */
@Composable
fun App() {
    var route by rememberSaveable { mutableStateOf("home") }
    var settings by rememberSaveable { mutableStateOf(false) }
    val parts = route.split(":")

    BackHandler(enabled = parts[0] != "home") {
        route = if (parts[0] == "play") "intro:${parts[1]}" else "home"
    }

    when (parts[0]) {
        "intro" -> {
            val g = Games.byId(parts[1])
            IntroScreen(g, onBack = { route = "home" }, onSettings = { settings = true }, onPlay = { d -> route = "play:${g.id}:$d" })
        }
        "play" -> {
            val g = Games.byId(parts[1])
            val d = parts[2].toInt()
            val exit = { route = "intro:${g.id}" }
            when (g.id) {
                "nuts" -> NutsScreen(d, exit)
                "petdoku" -> PetdokuScreen(d, exit)
                "blocks" -> BlocksScreen(d, exit)
                else -> ComingSoonScreen(g, exit)
            }
        }
        else -> HomeScreen(onOpen = { g -> route = "intro:${g.id}" }, onMenu = { settings = true })
    }

    if (settings) {
        BackHandler { settings = false }
        val title = if (parts[0] == "home") "OFFLINE GAMES" else Games.byId(parts[1]).title
        SettingsDialog(title) { settings = false }
    }
}
