package com.example.offlinegames.games

import android.graphics.Paint
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.example.offlinegames.data.Store
import com.example.offlinegames.ui.*
import kotlin.random.Random

// ---------------------------------------------------------------- logic
typealias Bolts = List<List<Int>> // each bolt: bottom -> top, values are colour ids

object NutsLogic {
    const val CAP = 5

    fun colorCount(diff: Int, level: Int) = (4 + diff + (level - 1) / 8).coerceAtMost(10)

    fun isSolved(b: Bolts, cap: Int = CAP) =
        b.all { it.isEmpty() || (it.size == cap && it.all { n -> n == it[0] }) }

    fun canMove(b: Bolts, from: Int, to: Int, cap: Int = CAP): Boolean {
        if (from == to) return false
        val f = b[from]
        val t = b[to]
        if (f.isEmpty() || t.size >= cap) return false
        return t.isEmpty() || t.last() == f.last()
    }

    /** Moves the whole top run of equal nuts as far as space allows. */
    fun move(b: Bolts, from: Int, to: Int, cap: Int = CAP): Bolts {
        val f = b[from].toMutableList()
        val t = b[to].toMutableList()
        val c = f.last()
        while (f.isNotEmpty() && f.last() == c && t.size < cap) t.add(f.removeAt(f.size - 1))
        return b.mapIndexed { i, l -> if (i == from) f else if (i == to) t else l }
    }

    private fun moves(b: Bolts, cap: Int): List<Pair<Int, Int>> {
        val out = ArrayList<Pair<Int, Int>>()
        for (f in b.indices) {
            if (b[f].isEmpty()) continue
            val uniform = b[f].all { it == b[f][0] }
            for (t in b.indices) {
                if (!canMove(b, f, t, cap)) continue
                if (b[t].isEmpty() && uniform) continue // pointless shuffle
                out.add(f to t)
            }
        }
        // prefer moves onto non-empty bolts
        return out.sortedBy { if (b[it.second].isEmpty()) 1 else 0 }
    }

    /** Bounded depth-first solver. Returns a move list or null if none was found within budget. */
    fun solve(start: Bolts, cap: Int = CAP, budget: Int = 40000): List<Pair<Int, Int>>? {
        val seen = HashSet<String>()
        val path = ArrayList<Pair<Int, Int>>()
        var left = budget
        fun key(b: Bolts) = b.map { it.joinToString(",") }.sorted().joinToString("|")
        fun dfs(b: Bolts, depth: Int): Boolean {
            if (isSolved(b, cap)) return true
            if (depth > 90 || left-- <= 0) return false
            if (!seen.add(key(b))) return false
            for (m in moves(b, cap)) {
                path.add(m)
                if (dfs(move(b, m.first, m.second, cap), depth + 1)) return true
                path.removeAt(path.size - 1)
            }
            return false
        }
        return if (dfs(start, 0)) path.toList() else null
    }

    fun generate(diff: Int, level: Int): Bolts {
        val colors = colorCount(diff, level)
        var attempt = 0
        while (true) {
            val rnd = Random(diff * 100_000L + level * 31L + attempt)
            val nuts = (0 until colors).flatMap { c -> List(CAP) { c } }.shuffled(rnd)
            val bolts: Bolts = (0 until colors).map { i -> nuts.subList(i * CAP, (i + 1) * CAP).toList() } + listOf(emptyList<Int>(), emptyList<Int>())
            if (!isSolved(bolts) && (attempt >= 12 || solve(bolts, CAP, 20000) != null)) return bolts
            attempt++
        }
    }
}

class NutsState(start: Bolts) {
    var bolts by mutableStateOf(start)
    var selected by mutableStateOf<Int?>(null)
    var hintsLeft by mutableIntStateOf(2)
    var addLeft by mutableIntStateOf(1)
    var marked by mutableStateOf<Pair<Int, Int>?>(null)
    val history = mutableStateListOf<Bolts>()
    val solved get() = NutsLogic.isSolved(bolts)

    fun tap(i: Int) {
        if (solved) return
        val s = selected
        marked = null
        when {
            s == null -> if (bolts[i].isNotEmpty()) selected = i
            s == i -> selected = null
            NutsLogic.canMove(bolts, s, i) -> {
                history.add(bolts)
                bolts = NutsLogic.move(bolts, s, i)
                selected = null
            }
            bolts[i].isNotEmpty() -> selected = i
            else -> selected = null
        }
    }

    fun undo() {
        if (history.isEmpty()) return
        bolts = history.removeAt(history.size - 1)
        selected = null; marked = null
    }

    fun hint() {
        if (hintsLeft <= 0 || solved) return
        val m = NutsLogic.solve(bolts)?.firstOrNull()
            ?: bolts.indices.flatMap { f -> bolts.indices.map { t -> f to t } }.firstOrNull { NutsLogic.canMove(bolts, it.first, it.second) }
        if (m != null) { marked = m; hintsLeft--; selected = null }
    }

    fun addBolt() {
        if (addLeft <= 0 || solved) return
        bolts = bolts + listOf(emptyList<Int>()); addLeft--
    }
}

// ---------------------------------------------------------------- UI
private val NUT_COLORS = listOf(
    Color(0xFFF57C00), Color(0xFFFBC02D), Color(0xFF0B8A00), Color(0xFF0F62E0), Color(0xFFD81B3F),
    Color(0xFF8E44AD), Color(0xFFF06292), Color(0xFF00ACC1), Color(0xFF8D6E63), Color(0xFF9CCC32)
)
private val SYMBOLS = listOf("\u2665", "\u2663", "\u2666", "\u2605", "\u25CF", "\u25B2", "\u25A0", "\u271A", "\u25C6", "\u2726")

@Composable
fun NutsScreen(diffIdx: Int, onExit: () -> Unit) {
    StatusBarIcons(darkIcons = false)
    val game = Games.byId("nuts")
    val d = Difficulty.entries[diffIdx]
    var level by remember { mutableIntStateOf(Store.level("nuts", diffIdx)) }
    var attempt by remember { mutableIntStateOf(0) }
    val st = remember(level, attempt) { NutsState(NutsLogic.generate(diffIdx, level)) }
    var done by remember(level, attempt) { mutableStateOf(false) }

    LaunchedEffect(st.solved) {
        if (st.solved) {
            Store.setLevel("nuts", diffIdx, level + 1)
            done = true
        }
    }

    Box(Modifier.fillMaxSize().background(game.screenBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            GameTopBar(
                Color.White, d.label, "Level $level", Color(0xFF3A2A55), onExit,
                { attempt++ }, restartEnabled = st.history.isNotEmpty()
            )
            Column(
                Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                val rows = st.bolts.indices.chunked(4)
                for (row in rows) {
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 14.dp)) {
                        for (i in row) {
                            BoltView(
                                nuts = st.bolts[i],
                                selected = st.selected == i,
                                marked = st.marked?.let { it.first == i || it.second == i } == true,
                                colorblind = Store.colorblind,
                                onClick = { st.tap(i) }
                            )
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                ActionButton("Undo", Color(0xFF4B4C62), Color(0xFF8B8CA3), enabled = st.history.isNotEmpty(), onClick = { st.undo() }) {
                    IconUndo(color = Color(0xFFB8BAD0))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    ActionButton("Hint", Pal.Yellow, Pal.Yellow, enabled = st.hintsLeft > 0, badge = st.hintsLeft, onClick = { st.hint() }) { IconBulb() }
                    ActionButton("Add", Pal.Yellow, Pal.Yellow, enabled = st.addLeft > 0, onClick = { st.addBolt() }) { IconPlus() }
                }
            }
        }
        if (done) LevelCompleteCard(level, onHome = onExit, onNext = { level += 1 })
    }
}

@Composable
private fun BoltView(nuts: List<Int>, selected: Boolean, marked: Boolean, colorblind: Boolean, onClick: () -> Unit) {
    val cap = NutsLogic.CAP
    val nutH = 19.dp
    val lift by animateDpAsState(if (selected) 16.dp else 0.dp, label = "lift")
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; isFakeBoldText = true } }
    Canvas(
        Modifier
            .size(width = 66.dp, height = nutH * cap + 52.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    ) {
        val cx = size.width / 2
        val nh = nutH.toPx()
        val nw = 52.dp.toPx()
        val plateTop = size.height - 16.dp.toPx()
        // plate and shaft
        drawOval(Color(0xFFD7DAE0), Offset(cx - 31.dp.toPx(), plateTop - 4.dp.toPx()), Size(62.dp.toPx(), 18.dp.toPx()))
        val shaftTop = plateTop - cap * nh - 12.dp.toPx()
        drawRoundRect(Color(0xFFBFC4CC), Offset(cx - 9.dp.toPx(), shaftTop), Size(18.dp.toPx(), plateTop - shaftTop), CornerRadius(5.dp.toPx()))
        var y = shaftTop + 4.dp.toPx()
        while (y < plateTop - 4.dp.toPx()) {
            drawLine(Color(0xFF9EA4AF), Offset(cx - 9.dp.toPx(), y), Offset(cx + 9.dp.toPx(), y), 1.dp.toPx())
            y += 4.dp.toPx()
        }
        nuts.forEachIndexed { i, c ->
            val isTop = i == nuts.lastIndex
            val dy = if (isTop) lift.toPx() else 0f
            val top = plateTop - (i + 1) * nh - dy
            val col = NUT_COLORS[c % NUT_COLORS.size]
            drawRoundRect(col.darken(0.25f), Offset(cx - nw / 2, top), Size(nw, nh + 2.dp.toPx()), CornerRadius(7.dp.toPx()))
            drawRoundRect(col, Offset(cx - nw / 2, top), Size(nw, nh * 0.78f), CornerRadius(7.dp.toPx()))
            if (isTop) {
                drawOval(col.lighten(0.18f), Offset(cx - nw / 2 + 3.dp.toPx(), top - 5.dp.toPx()), Size(nw - 6.dp.toPx(), 12.dp.toPx()))
                drawOval(Color(0xFFC9CDD6), Offset(cx - 10.dp.toPx(), top - 5.dp.toPx()), Size(20.dp.toPx(), 12.dp.toPx()))
            }
            if (colorblind) {
                paint.color = col.darken(0.35f).toArgb()
                paint.textSize = 13.dp.toPx()
                drawContext.canvas.nativeCanvas.drawText(SYMBOLS[c % SYMBOLS.size], cx, top + nh * 0.62f, paint)
            }
        }
        if (marked) {
            drawRoundRect(Color.White, Offset(2.dp.toPx(), 2.dp.toPx()), Size(size.width - 4.dp.toPx(), size.height - 4.dp.toPx()), CornerRadius(14.dp.toPx()), style = Stroke(2.5f.dp.toPx()))
        }
    }
}
