package com.example.offlinegames.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Calendar

data class Bests(val today: Int, val week: Int, val allTime: Int)

/** Local persistence (SharedPreferences). Fully offline. */
object Store {
    private lateinit var sp: SharedPreferences

    var colorblind by mutableStateOf(false)
        private set

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("offline_games", Context.MODE_PRIVATE)
        colorblind = sp.getBoolean("colorblind", false)
    }

    fun setColorblind(v: Boolean) {
        colorblind = v
        sp.edit().putBoolean("colorblind", v).apply()
    }

    fun lastDifficulty(game: String): Int = sp.getInt("diff_$game", 1)
    fun setLastDifficulty(game: String, d: Int) = sp.edit().putInt("diff_$game", d).apply()

    fun level(game: String, diff: Int): Int = sp.getInt("level_${game}_$diff", 1)
    fun setLevel(game: String, diff: Int, v: Int) = sp.edit().putInt("level_${game}_$diff", v).apply()

    private fun dayKey(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    private fun weekKey(): Int {
        val c = Calendar.getInstance()
        return c.get(Calendar.YEAR) * 100 + c.get(Calendar.WEEK_OF_YEAR)
    }

    private fun readKeyed(k: String, key: Int): Int {
        val s = sp.getString(k, null) ?: return 0
        val p = s.split(":")
        return if (p.size == 2 && p[0].toIntOrNull() == key) p[1].toIntOrNull() ?: 0 else 0
    }

    fun bests(game: String, diff: Int): Bests = Bests(
        today = readKeyed("day_${game}_$diff", dayKey()),
        week = readKeyed("week_${game}_$diff", weekKey()),
        allTime = sp.getInt("all_${game}_$diff", 0)
    )

    /** Records a score and returns the updated bests. */
    fun record(game: String, diff: Int, score: Int): Bests {
        val b = bests(game, diff)
        val nb = Bests(maxOf(b.today, score), maxOf(b.week, score), maxOf(b.allTime, score))
        sp.edit()
            .putString("day_${game}_$diff", "${dayKey()}:${nb.today}")
            .putString("week_${game}_$diff", "${weekKey()}:${nb.week}")
            .putInt("all_${game}_$diff", nb.allTime)
            .apply()
        return nb
    }
}
