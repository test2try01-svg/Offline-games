package com.example.offlinegames.ui

import androidx.compose.ui.graphics.Color

enum class Difficulty(val label: String, val color: Color) {
    Easy("EASY", Pal.Green),
    Medium("MEDIUM", Pal.Orange),
    Hard("HARD", Pal.Red),
    ExtraHard("EXTRA HARD", Pal.Indigo),
    UltraHard("ULTRA HARD", Pal.Magenta)
}

data class GameInfo(
    val id: String,
    val title: String,
    val description: String,
    val hasLevels: Boolean,
    val implemented: Boolean,
    val cardBg: Color,
    val titleColor: Color,
    val headerBg: Color,
    val screenBg: Color,
    val screenText: Color,
    val badge: String? = null,
    val badgeColor: Color = Color.Unspecified
)

object Games {
    val all = listOf(
        GameInfo(
            "nuts", "NUTS AND BOLTS",
            "Move nuts between the bolts until all the nuts on each bolt are the same colour!\n\nYou can only move nuts onto other nuts of the same colour.",
            hasLevels = true, implemented = true,
            cardBg = Color(0xFF261E33), titleColor = Color(0xFFFF4F83), headerBg = Color(0xFF30203F),
            screenBg = Color(0xFF281845), screenText = Color.White,
            badge = "MOST\nPOPULAR!", badgeColor = Color(0xFF12BDE8)
        ),
        GameInfo(
            "petdoku", "PETDOKU",
            "Place cats so that every colour, every row and every column has exactly one cat.\n\nCats cannot touch each other, not even diagonally.",
            hasLevels = true, implemented = true,
            cardBg = Color(0xFFFCF0DF), titleColor = Color(0xFFD7447F), headerBg = Color(0xFF9A5A7A),
            screenBg = Color(0xFFF8F0E5), screenText = Color(0xFF9A4F73),
            badge = "NEW!", badgeColor = Color(0xFFF0524F)
        ),
        GameInfo(
            "snakes", "SNAKES",
            "Slither around, eat glowing dots and grow. Don't crash into other snakes!",
            hasLevels = false, implemented = false,
            cardBg = Color(0xFF0E0D12), titleColor = Color(0xFFFFC22E), headerBg = Color(0xFF241B30),
            screenBg = Color(0xFF30283A), screenText = Color.White
        ),
        GameInfo(
            "pointers", "POINTERS",
            "Follow the arrows to find your way through the maze.",
            hasLevels = true, implemented = false,
            cardBg = Color(0xFFC2EAF6), titleColor = Color(0xFF08A0CE), headerBg = Color(0xFF4A8CA0),
            screenBg = Color(0xFFD2E8E1), screenText = Color(0xFF9A4F73)
        ),
        GameInfo(
            "maze", "MAZE PAINT",
            "Roll the ball around the maze and paint every tile.",
            hasLevels = true, implemented = false,
            cardBg = Color(0xFF22232A), titleColor = Color(0xFFFF3B6B), headerBg = Color(0xFF2C2C36),
            screenBg = Color(0xFF22232A), screenText = Color.White
        ),
        GameInfo(
            "matching", "MATCHING NUMBERS",
            "Find and remove matching pairs of numbers.",
            hasLevels = true, implemented = false,
            cardBg = Color(0xFF05BFEF), titleColor = Color.White, headerBg = Color(0xFF0A7FA0),
            screenBg = Color(0xFFFFFFFF), screenText = Color(0xFF3C4654)
        ),
        GameInfo(
            "blocks", "COLOR BLOCKS",
            "Drag blocks onto the grid. Fill a whole row or column to clear it. The game ends when no block fits.",
            hasLevels = false, implemented = true,
            cardBg = Color(0xFF3A2845), titleColor = Color(0xFFFFC22E), headerBg = Color(0xFF3A2845),
            screenBg = Color(0xFF3A2845), screenText = Color.White
        ),
        GameInfo(
            "guess", "GUESS THE PERSON",
            "Work out who the mystery person is.",
            hasLevels = true, implemented = false,
            cardBg = Color(0xFF975B9C), titleColor = Color(0xFFFFC22E), headerBg = Color(0xFF6E3E73),
            screenBg = Color(0xFF975B9C), screenText = Color.White
        )
    )

    fun byId(id: String) = all.first { it.id == id }
}
