package com.example.offlinegames.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.offlinegames.data.Store
import com.example.offlinegames.ui.*
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

// ---------------------------------------------------------------- logic
private const val N = 8

class Piece(val rows: List<String>, val color: Color) {
    val h = rows.size
    val w = rows[0].length
    val cells: List<Pair<Int, Int>> = rows.flatMapIndexed { r, s -> s.mapIndexedNotNull { c, ch -> if (ch == 'X') r to c else null } }
}

private val SHAPES: List<List<String>> = listOf(
    listOf("X"), listOf("XX"), listOf("XXX"), listOf("XXXX"), listOf("XXXXX"),
    listOf("X", "X"), listOf("X", "X", "X"), listOf("X", "X", "X", "X"), listOf("X", "X", "X", "X", "X"),
    listOf("XX", "XX"), listOf("XXX", "XXX", "XXX"), listOf("XXX", "XXX"), listOf("XX", "XX", "XX"),
    listOf("X.", "XX"), listOf(".X", "XX"), listOf("XX", "X."), listOf("XX", ".X"),
    listOf("..X", "..X", "XXX"), listOf("X..", "X..", "XXX"), listOf("XXX", "..X", "..X"), listOf("XXX", "X..", "X.."),
    listOf("XXX", ".X."), listOf(".X.", "XXX"), listOf("X.", "XX", "X."), listOf(".X", "XX", ".X"),
    listOf("XX.", ".XX"), listOf(".XX", "XX.")
)
private val PIECE_COLORS = listOf(
    Color(0xFFE03127), Color(0xFF7ED321), Color(0xFF00D9E0), Color(0xFFFFC107),
    Color(0xFFA855F7), Color(0xFFFF8A1F), Color(0xFF3B82F6)
)

class BlocksState(private val diff: Int, seed: Long) {
    private val rnd = Random(seed)
    var board by mutableStateOf(IntArray(N * N))      // 0 = empty, otherwise ARGB colour
    var tray by mutableStateOf(List<Piece?>(3) { null })
    var score by mutableIntStateOf(0)
    var over by mutableStateOf(false)

    init { refill() }

    private fun randomPiece(): Piece {
        val maxCells = if (diff == 0) 4 else 9
        val pool = SHAPES.indices.filter { i -> SHAPES[i].sumOf { r -> r.count { it == 'X' } } <= maxCells }
        var i = pool[rnd.nextInt(pool.size)]
        if (diff >= 2) { // harder modes tend to deal bigger pieces
            val j = pool[rnd.nextInt(pool.size)]
            if (SHAPES[j].sumOf { r -> r.count { it == 'X' } } > SHAPES[i].sumOf { r -> r.count { it == 'X' } }) i = j
        }
        return Piece(SHAPES[i], PIECE_COLORS[i % PIECE_COLORS.size])
    }

    private fun refill() { tray = List(3) { randomPiece() }; checkOver() }

    fun fits(p: Piece, r: Int, c: Int, b: IntArray = board): Boolean =
        p.cells.all { (pr, pc) -> r + pr in 0 until N && c + pc in 0 until N && b[(r + pr) * N + c + pc] == 0 }

    private fun anyFit(): Boolean = tray.any { p -> p != null && (0 until N).any { r -> (0 until N).any { c -> fits(p, r, c) } } }

    private fun checkOver() { over = !anyFit() }

    fun place(slot: Int, r: Int, c: Int): Boolean {
        val p = tray[slot] ?: return false
        if (over || !fits(p, r, c)) return false
        val b = board.clone()
        p.cells.forEach { (pr, pc) -> b[(r + pr) * N + c + pc] = p.color.toArgb() }
        var gained = p.cells.size
        val fullRows = (0 until N).filter { rr -> (0 until N).all { b[rr * N + it] != 0 } }
        val fullCols = (0 until N).filter { cc -> (0 until N).all { b[it * N + cc] != 0 } }
        for (rr in fullRows) for (x in 0 until N) b[rr * N + x] = 0
        for (cc in fullCols) for (y in 0 until N) b[y * N + cc] = 0
        val lines = fullRows.size + fullCols.size
        if (lines > 0) gained += lines * 10 * lines // combo bonus (estimated rule)
        score += gained
        board = b
        tray = tray.mapIndexed { i, t -> if (i == slot) null else t }
        if (tray.all { it == null }) refill() else checkOver()
        return true
    }

}

// ---------------------------------------------------------------- UI
private class Geom(val w: Float, val h: Float) {
    val side = min(w * 0.76f, h * 0.62f)
    val cell = side / N
    val left = (w - side) / 2f
    val trayArea = side * 0.45f
    val gap = cell * 0.8f
    val top = ((h - (side + gap + trayArea)) / 2f).coerceAtLeast(0f)
    val trayCell = cell * 0.6f
    val trayTop = top + side + gap
    fun slotCenter(i: Int) = Offset(w / 6f + i * w / 3f, trayTop + trayArea / 2f)
    val lift = cell * 1.8f
}

@Composable
fun BlocksScreen(diffIdx: Int, onExit: () -> Unit) {
    StatusBarIcons(darkIcons = false)
    val game = Games.byId("blocks")
    val d = Difficulty.entries[diffIdx]
    var attempt by remember { mutableIntStateOf(0) }
    val st = remember(attempt) { BlocksState(diffIdx, System.nanoTime()) }
    var best by remember(attempt) { mutableIntStateOf(Store.bests("blocks", diffIdx).allTime) }
    var finalBests by remember(attempt) { mutableStateOf<com.example.offlinegames.data.Bests?>(null) }
    var dragSlot by remember(attempt) { mutableIntStateOf(-1) }
    var dragPos by remember(attempt) { mutableStateOf(Offset.Zero) }

    LaunchedEffect(st.over) {
        if (st.over) { finalBests = Store.record("blocks", diffIdx, st.score); best = finalBests!!.allTime }
    }
    val shownBest = maxOf(best, st.score)

    Box(Modifier.fillMaxSize().background(game.screenBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).height(64.dp)) {
                RoundButton(onExit, Modifier.align(Alignment.CenterStart)) { IconChevron() }
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ScorePill("${d.label} MODE", st.score, Color.White)
                    ScorePill("ALL TIME", shownBest, Pal.Teal)
                }
                RoundButton({ attempt++ }, Modifier.align(Alignment.CenterEnd)) { IconRestart() }
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val g = remember(constraints.maxWidth, constraints.maxHeight) {
                    Geom(constraints.maxWidth.toFloat(), constraints.maxHeight.toFloat())
                }
                fun topLeftFor(p: Piece): Offset = Offset(dragPos.x - p.w * g.cell / 2f, dragPos.y - g.lift - p.h * g.cell / 2f)
                fun snap(p: Piece): Pair<Int, Int> {
                    val tl = topLeftFor(p)
                    return ((tl.y - g.top) / g.cell).roundToInt() to ((tl.x - g.left) / g.cell).roundToInt()
                }
                Canvas(
                    Modifier.fillMaxSize().pointerInput(g, attempt) {
                        detectDragGestures(
                            onDragStart = { o ->
                                if (st.over || o.y < g.top + g.side) return@detectDragGestures
                                val i = (o.x / (g.w / 3f)).toInt().coerceIn(0, 2)
                                if (st.tray[i] != null) { dragSlot = i; dragPos = o }
                            },
                            onDrag = { ch, amount -> if (dragSlot >= 0) { ch.consume(); dragPos += amount } },
                            onDragEnd = {
                                val p = st.tray.getOrNull(dragSlot)
                                if (p != null) {
                                    val (r, c) = snap(p)
                                    st.place(dragSlot, r, c)
                                }
                                dragSlot = -1
                            },
                            onDragCancel = { dragSlot = -1 }
                        )
                    }
                ) {
                    // board
                    drawRoundRect(Color(0xFF160F1A), Offset(g.left - 8f, g.top - 8f), Size(g.side + 16f, g.side + 16f), CornerRadius(22f))
                    for (r in 0 until N) for (c in 0 until N) {
                        val v = st.board[r * N + c]
                        val o = Offset(g.left + c * g.cell, g.top + r * g.cell)
                        if (v == 0) drawRoundRect(Color(0xFF281A33), o + Offset(2f, 2f), Size(g.cell - 4f, g.cell - 4f), CornerRadius(8f))
                        else drawBlock(o, g.cell, Color(v))
                    }
                    // ghost preview + dragged piece
                    val dragged = st.tray.getOrNull(dragSlot)
                    if (dragged != null) {
                        val (sr, sc) = snap(dragged)
                        if (st.fits(dragged, sr, sc)) {
                            dragged.cells.forEach { (pr, pc) ->
                                drawBlock(Offset(g.left + (sc + pc) * g.cell, g.top + (sr + pr) * g.cell), g.cell, dragged.color.copy(alpha = 0.35f))
                            }
                        }
                        val tl = topLeftFor(dragged)
                        dragged.cells.forEach { (pr, pc) -> drawBlock(tl + Offset(pc * g.cell, pr * g.cell), g.cell, dragged.color) }
                    }
                    // tray
                    for (i in 0 until 3) {
                        val p = st.tray[i] ?: continue
                        if (i == dragSlot) continue
                        val c = g.slotCenter(i)
                        val tl = Offset(c.x - p.w * g.trayCell / 2f, c.y - p.h * g.trayCell / 2f)
                        p.cells.forEach { (pr, pc) -> drawBlock(tl + Offset(pc * g.trayCell, pr * g.trayCell), g.trayCell, p.color) }
                    }
                }
            }
        }
        if (st.over && finalBests != null) {
            GameOverCard(d.label, st.score, finalBests!!, d, onExit) { attempt++ }
        }
    }
}

private fun DrawScope.drawBlock(o: Offset, s: Float, color: Color) {
    drawRect(color, o, Size(s, s))
    drawRect(Color.White.copy(alpha = 0.28f * color.alpha), o, Size(s, s * 0.12f))
    drawRect(Color.White.copy(alpha = 0.18f * color.alpha), o, Size(s * 0.12f, s))
    drawRect(Color.Black.copy(alpha = 0.18f * color.alpha), o + Offset(0f, s * 0.88f), Size(s, s * 0.12f))
    drawRect(color.darken(0.08f), o + Offset(s * 0.16f, s * 0.16f), Size(s * 0.68f, s * 0.68f))
}

@Composable
private fun ScorePill(label: String, value: Int, color: Color) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFF16101A)).padding(horizontal = 18.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GText(label, 14, color)
        GText(value.toString(), 28, color)
    }
}
