package com.example.offlinegames.games

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.offlinegames.data.Store
import com.example.offlinegames.ui.*
import kotlin.math.abs
import kotlin.random.Random

// ---------------------------------------------------------------- logic
class PetPuzzle(val n: Int, val region: Array<IntArray>, val sol: IntArray)

object PetLogic {
    private val SIZES = intArrayOf(5, 7, 8, 9, 10)

    fun generate(diff: Int, level: Int): PetPuzzle {
        val n = SIZES[diff]
        val rnd = Random(diff * 1000L + level)
        val sol = IntArray(n)
        val used = BooleanArray(n)
        fun place(r: Int): Boolean {
            if (r == n) return true
            for (c in (0 until n).shuffled(rnd)) {
                if (used[c]) continue
                if (r > 0 && abs(sol[r - 1] - c) <= 1) continue
                used[c] = true; sol[r] = c
                if (place(r + 1)) return true
                used[c] = false
            }
            return false
        }
        place(0)
        val reg = Array(n) { IntArray(n) { -1 } }
        for (r in 0 until n) reg[r][sol[r]] = r
        var left = n * n - n
        val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
        while (left > 0) {
            for (id in (0 until n).shuffled(rnd)) {
                if (left == 0) break
                val frontier = ArrayList<IntArray>()
                for (r in 0 until n) for (c in 0 until n) if (reg[r][c] == id) {
                    for (d in dirs) {
                        val nr = r + d[0]; val nc = c + d[1]
                        if (nr in 0 until n && nc in 0 until n && reg[nr][nc] == -1) frontier.add(intArrayOf(nr, nc))
                    }
                }
                if (frontier.isEmpty()) continue
                val p = frontier[rnd.nextInt(frontier.size)]
                reg[p[0]][p[1]] = id
                left--
            }
        }
        return PetPuzzle(n, reg, sol)
    }

    /** Two cat positions clash if they share a row, column, colour region, or touch (incl. diagonally). */
    fun clash(p: PetPuzzle, r1: Int, c1: Int, r2: Int, c2: Int) =
        r1 == r2 || c1 == c2 || p.region[r1][c1] == p.region[r2][c2] || (abs(r1 - r2) <= 1 && abs(c1 - c2) <= 1)

    fun conflicts(cells: Array<IntArray>, p: PetPuzzle, r: Int, c: Int): Boolean {
        for (rr in 0 until p.n) for (cc in 0 until p.n) {
            if (cells[rr][cc] == 2 && !(rr == r && cc == c) && clash(p, rr, cc, r, c)) return true
        }
        return false
    }
}

private fun copyOf(a: Array<IntArray>) = Array(a.size) { a[it].clone() }

/** cell values: 0 empty, 1 cross-mark, 2 cat */
class PetState(val p: PetPuzzle) {
    var cells by mutableStateOf(Array(p.n) { IntArray(p.n) })
    var lives by mutableIntStateOf(3)
    var hints by mutableIntStateOf(1)
    val history = mutableStateListOf<Array<IntArray>>()
    val cats get() = cells.sumOf { row -> row.count { it == 2 } }
    val won get() = cats == p.n
    val lost get() = lives <= 0

    fun tap(r: Int, c: Int) {
        if (won || lost) return
        history.add(copyOf(cells))
        val a = copyOf(cells)
        val next = (a[r][c] + 1) % 3
        if (next == 2 && PetLogic.conflicts(a, p, r, c)) {
            a[r][c] = 1
            lives--
        } else a[r][c] = next
        cells = a
    }

    fun undo() {
        if (history.isNotEmpty()) cells = history.removeAt(history.size - 1)
    }

    fun hint() {
        if (hints <= 0 || won || lost) return
        for (r in 0 until p.n) {
            val c = p.sol[r]
            if (cells[r][c] != 2) {
                history.add(copyOf(cells))
                val a = copyOf(cells)
                // remove any cat that would block the hinted position
                for (rr in 0 until p.n) for (cc in 0 until p.n) {
                    if (a[rr][cc] == 2 && PetLogic.clash(p, rr, cc, r, c)) a[rr][cc] = 0
                }
                a[r][c] = 2
                cells = a
                hints--
                return
            }
        }
    }
}

// ---------------------------------------------------------------- UI
private val REGION_COLORS = listOf(
    Color(0xFFD3B029), Color(0xFFDF86B0), Color(0xFF6989C9), Color(0xFFEC9A60), Color(0xFF57AF63),
    Color(0xFFD4706A), Color(0xFF4FAEDA), Color(0xFFA37BC9), Color(0xFF4BB5A8), Color(0xFFB58A5C)
)

@Composable
fun PetdokuScreen(diffIdx: Int, onExit: () -> Unit) {
    StatusBarIcons(darkIcons = true)
    val game = Games.byId("petdoku")
    val d = Difficulty.entries[diffIdx]
    var level by remember { mutableIntStateOf(Store.level("petdoku", diffIdx)) }
    var attempt by remember { mutableIntStateOf(0) }
    val st = remember(level, attempt) { PetState(PetLogic.generate(diffIdx, level)) }
    var recorded by remember(level, attempt) { mutableStateOf(false) }

    LaunchedEffect(st.won) {
        if (st.won && !recorded) { recorded = true; Store.setLevel("petdoku", diffIdx, level + 1) }
    }

    Box(Modifier.fillMaxSize().background(game.screenBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            GameTopBar(game.screenText, d.label, "Level $level", Color(0xFFB8A6A6), onExit, { attempt++ })
            Spacer(Modifier.height(10.dp))
            Row(Modifier.align(Alignment.CenterHorizontally), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color.White).padding(horizontal = 14.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    CatFace(Modifier.size(34.dp))
                    Spacer(Modifier.width(18.dp))
                    GText("${st.cats}/${st.p.n}", 26, if (st.cats == st.p.n) Pal.Green else Color(0xFF3FB04E))
                }
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color.White).padding(horizontal = 18.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(3) { i -> Heart(if (i < st.lives) Color(0xFFB00010) else Color(0xFFE2D6D6)) }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                RuleChip(0, "1 Cat per color", Modifier.weight(1f))
                RuleChip(1, "1 Cat per column and row", Modifier.weight(1f))
                RuleChip(2, "Cats cannot touch", Modifier.weight(1f))
            }
            Spacer(Modifier.height(14.dp))
            // board
            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (r in 0 until st.p.n) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (c in 0 until st.p.n) {
                            val v = st.cells[r][c]
                            Box(
                                Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(9.dp))
                                    .background(REGION_COLORS[st.p.region[r][c] % REGION_COLORS.size])
                                    .clickable { st.tap(r, c) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (v == 1) Canvas(Modifier.fillMaxSize(0.4f)) {
                                    val s = size.width
                                    val col = Color.Black.copy(alpha = 0.35f)
                                    drawLine(col, Offset(0f, 0f), Offset(s, s), s * .16f, StrokeCap.Round)
                                    drawLine(col, Offset(s, 0f), Offset(0f, s), s * .16f, StrokeCap.Round)
                                }
                                if (v == 2) CatFace(Modifier.fillMaxSize(0.92f))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                ActionButton("Undo", Color(0xFF2E3440), Pal.Slate, enabled = st.history.isNotEmpty(), onClick = { st.undo() }) {
                    IconUndo(color = Color(0xFF9AA0AD))
                }
                ActionButton("Hint", Pal.Yellow, Pal.Yellow, enabled = st.hints > 0, badge = st.hints, onClick = { st.hint() }) { IconBulb() }
            }
        }
        if (st.won) LevelCompleteCard(level, onHome = onExit, onNext = { level += 1 })
        if (st.lost) GameOverCard(d.label, st.cats, Store.record("petdoku", diffIdx, st.cats), d, onExit) { attempt++ }
    }
}

@Composable
private fun Heart(color: Color) {
    Canvas(Modifier.size(26.dp)) {
        val s = size.width
        drawCircle(color, s * .27f, Offset(s * .3f, s * .35f))
        drawCircle(color, s * .27f, Offset(s * .7f, s * .35f))
        val p = androidx.compose.ui.graphics.Path().apply {
            moveTo(s * .05f, s * .45f); lineTo(s * .5f, s * .95f); lineTo(s * .95f, s * .45f); close()
        }
        drawPath(p, color)
    }
}

@Composable
private fun RuleChip(kind: Int, text: String, modifier: Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFF3E2D6)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Canvas(Modifier.size(34.dp)) {
            val cell = size.width / 3
            val crosses = when (kind) {
                0 -> setOf(0 to 0, 0 to 1, 1 to 0)
                1 -> setOf(0 to 1, 1 to 0, 1 to 2, 2 to 1)
                else -> (0..2).flatMap { r -> (0..2).map { c -> r to c } }.filter { it != (1 to 1) }.toSet()
            }
            for (r in 0..2) for (c in 0..2) {
                val on = (r to c) in crosses
                drawRoundRect(
                    if (r == 1 && c == 1) Color.White else if (on) Color(0xFFB57A5A) else Color(0xFFE2C7B5),
                    Offset(c * cell + 1.dp.toPx(), r * cell + 1.dp.toPx()), Size(cell - 2.dp.toPx(), cell - 2.dp.toPx()), CornerRadius(2.dp.toPx())
                )
            }
        }
        GText(text, 11, Color(0xFF8A5A4A), Modifier.padding(start = 4.dp), weight = androidx.compose.ui.text.font.FontWeight.Medium, align = TextAlign.Start)
    }
}
