# Offline Games (Kotlin + Jetpack Compose) — Stage 1

Native rebuild of the "Offline Games" puzzle collection, based on the supplied screenshots.
The original is a Unity/IL2CPP app, so no UI source existed; all visuals and rules here are
**reconstructed from screenshots** and are estimates, not extracted values.

## Build
1. Install Android Studio (Ladybug or newer) and JDK 17.
2. File > Open > select this folder. Let Gradle sync (downloads Gradle 8.9 automatically).
3. Run on a device/emulator (API 23+). Portrait only. No INTERNET permission, no ads, no billing.

NOTE: this project was written without an Android SDK available, so it has NOT been compiled or
run yet. Expect to fix a few compile errors on first build; send them back and they will be fixed.

## Status
| Game | Status |
|---|---|
| Home grid, intro screen (difficulty slider, faces, PLAY, help), settings (colorblind) | Done |
| Nuts and Bolts (levels, undo, hint, add bolt, colorblind symbols) | Done |
| Petdoku (generated regions, 3 lives, undo, hint) | Done |
| Color Blocks (drag & drop 8x8, line clears, best scores) | Done (scoring rule estimated) |
| Snakes, Pointers, Maze Paint, Matching Numbers, Guess the Person | Listed, not built yet (Coming Soon screen) |

## Known differences from the original
- Fonts, card illustrations and difficulty faces are simplified drawings; original art not available.
- Rewarded-video buttons (Add, Save Me) are free/removed. Hint and Add limits are estimated.
- Level generation is deterministic per (difficulty, level) but differs from the original levels.
- Game state is not kept across rotation (portrait-locked) or process death; progress and bests are saved.
- Hamburger menu opens Settings only (its real contents are unknown).

## Build an APK with GitHub (no Android Studio needed)
1. Create a GitHub repository and upload the contents of this folder (including `.github/workflows/build.yml`).
2. Open the repo's **Actions** tab, choose **Build APK**, press **Run workflow** (it also runs on every push).
3. When the run turns green, open it and download **OfflineGames-debug-apk** under *Artifacts*.
4. Unzip it and install `app-debug.apk` on your phone (allow "Install unknown apps").
If the run fails, open the failed step and send the error lines for fixing.
